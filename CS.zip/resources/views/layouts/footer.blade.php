<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span> جميع الحقوق محفوظة لكلية علوم الحاسوب وتقانة المعلومات 2022 &copy;</span>
		</div>
	</div>
<!-- Footer closed -->
